

###############
from flask import Flask, render_template, request, redirect, session
import mysql.connector

app = Flask(__name__, template_folder="templates", static_folder="static")

app.secret_key = "library_secret_key"

# MySQL Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="salonigupta20@",
    database="library_db"
)

cursor = db.cursor()

# ------------------ LOGIN ROUTE ------------------

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        query = "SELECT * FROM users WHERE email=%s AND password=%s"
        cursor.execute(query, (email, password))
        user = cursor.fetchone()

        if user:
            session['user_id'] = user[0]
            session['role'] = user[4]

            if user[4] == 'admin':
                return redirect('/admin_dashboard')
            else:
                return redirect('/user_dashboard')
        else:
            return "Invalid Email or Password"

    return render_template("login.html")

# ------------------ ADMIN DASHBOARD ------------------

@app.route('/admin_dashboard')
def admin_dashboard():
    if session.get('role') == 'admin':
        return "<h2>Welcome Admin</h2><a href='/logout'>Logout</a>"
    else:
        return "Access Denied"

# ------------------ USER DASHBOARD ------------------

@app.route('/user_dashboard')
def user_dashboard():
    if session.get('role') == 'user':
        return "<h2>Welcome User</h2><a href='/logout'>Logout</a>"
    else:
        return "Access Denied"

# ------------------ LOGOUT ------------------

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ------------------ RUN APP ------------------

if __name__ == "__main__":
    app.run(debug=True)

###Maintenance Route
@app.route('/maintenance')
def maintenance():
    if session.get('role') == 'admin':
        return render_template("maintenance.html")
    else:
        return "Access Denied"

###Maintenance Route 2n
@app.route('/add_membership', methods=['GET', 'POST'])
def add_membership():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        duration = request.form['duration']

        if not name or not email:
            return "All fields are mandatory"

        query = "INSERT INTO memberships (name, email, duration) VALUES (%s, %s, %s)"
        cursor.execute(query, (name, email, duration))
        db.commit()

        return "Membership Added Successfully"

    return render_template("add_membership.html")


#####STEP 2: Route Add in app.py

@app.route('/add_book', methods=['GET', 'POST'])
def add_book():
    if session.get('role') != 'admin':
        return "Access Denied"

    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        book_type = request.form['type']
        quantity = request.form['quantity']

        if not title or not author or not quantity:
            return render_template("add_book.html", error="All fields are mandatory")

        query = "INSERT INTO books (title, author, type, quantity, available) VALUES (%s,%s,%s,%s,%s)"
        cursor.execute(query, (title, author, book_type, quantity, quantity))
        db.commit()

        return render_template("add_book.html", success="Book Added Successfully")

    return render_template("add_book.html")



